#include<stdio.h>
void main()
{
int a[5]={100,200,3000,400,500};
int b=2000;
int add[10],i;
printf("Enter the index you want to find");
scanf("%d",&i);
{
  add[i]=b+(i-1)*4;
  printf("%d",add[i]);
}
}
