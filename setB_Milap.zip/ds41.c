#include<stdio.h>

int main()
{
        int a[10][10];
        int s[10][3];
        int m,n,i,j,count=0;
        printf("Enter the no. of rows and columns for matrix: \n");
        scanf("%d%d",&m,&n);
        printf("\n Enter a sparse matrix :\n ");
        for(i=0;i<m;i++)
             for(j=0;j<n;j++)
               {
                 scanf("%d",&a[i][j]);
               }
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
      
            {
          if(a[i][j]!=0)
                {
                   s[count][0]=i;
                   s[count][1]=j;
                   s[count][2]=a[i][j];
                   count++;
                 }
            }
for (i=0;i<count;i++)
{
  printf("\n %d %d %d",s[i][0],s[i][1],s[i][2]);
}

for(i=0;i<m;i++)
             for(j=0;j<n;j++)
        {
          if(a[i][j]!=0)
                {
                    printf("\n %d %d %d",i+1,j+1,a[i][j]);                 
                 }
          }
return 0;
}
