#include<stdio.h>
void main()
{
       int base,rows,cols,i,j,a;
       printf("Enter Base Address :");
       scanf("%d",&base);
       printf("Enter rows and columns : \n");
       scanf("%d%d",&rows,&cols);
       printf("Enter index you want address :\n");
       scanf("%d%d",&i,&j);
       printf("Matrix is row major(1) or column major(0):\n");
       scanf("%d",&a);
       int add;
      if(a==0)
           add = base + ((i-1)*cols*4 + (j-1)*4);
      else
           add = base + ((j-1)*rows*4 + (i-1)*4);
      printf("Address of elements at index [%d][%d] is %d\n",i,j,add);
}

