#include<stdio.h>
#include<stdlib.h>

int main()
{
 
   int i,j;
   int a[i][j];
   int n1,n2,power1,power2;

   printf("Enter the highest degree of x and y :\n");
   scanf("%d%d",&n1,&n2);
  
    printf("coffecient\n ");

   for(i=0;i<n1;i++)
      {
        for (j=0;j<n2;j++)
            {
              scanf("%d",&a[i][j]);
              }
         }
     power1 = n1;
     power2=n2;
    printf("poly is: \n");
   for(i=0;i<n1;i++)
      {
        for (j=0;j<n2;j++)
            {
               if(power1<0 || power2<0)
                   {
                      break;
                    }
          
                 if (a[i][j]>0)
                         printf("+");
                 else if (a[i][j]<0)
                          printf("-");
                 else
                       printf(" ");
              printf("%dX^%dY^%d",abs(a[i][j]),power1--,power2--);
              }
         }
   
   
   

return 0;
  

}

